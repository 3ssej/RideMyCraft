package com.quequiere.ridemycraft.a;

import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

public abstract class a
{
  public abstract void a(Player paramPlayer, String[] paramArrayOfString);

  public abstract void a(ConsoleCommandSender paramConsoleCommandSender, String[] paramArrayOfString);
}

/* Location:           C:\Users\keith\Desktop\RideMyCraft-1.5.6-Heavy-SNAPSHOT-small.jar
 * Qualified Name:     com.quequiere.ridemycraft.a.a
 * JD-Core Version:    0.6.2
 */