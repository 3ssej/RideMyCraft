package com.quequiere.ridemycraft.a.a.a.a;

import com.quequiere.ridemycraft.a.a.g;
import me.xhawk87.PopupMenuAPI.MenuItem;
import me.xhawk87.PopupMenuAPI.PopupMenu;
import org.bukkit.entity.Player;
import org.bukkit.material.MaterialData;

final class A extends MenuItem
{
  A(z paramz, String paramString, MaterialData paramMaterialData, PopupMenu paramPopupMenu, com.quequiere.ridemycraft.a parama, com.quequiere.ridemycraft.car.a parama1)
  {
    super(paramString, paramMaterialData);
  }

  public final void onClick(Player paramPlayer)
  {
    this.a.closeMenu(paramPlayer);
    double d = Math.round(this.b.c * 10.0F) / 10.0F;
    this.c.a(d);
    g.a(paramPlayer, this.c);
    try
    {
      this.c.a(true);
      return;
    }
    catch (com.quequiere.ridemycraft.b.a locala)
    {
      (paramPlayer = locala).printStackTrace();
    }
  }
}

/* Location:           C:\Users\keith\Desktop\RideMyCraft-1.5.6-Heavy-SNAPSHOT-small.jar
 * Qualified Name:     com.quequiere.ridemycraft.a.a.a.a.A
 * JD-Core Version:    0.6.2
 */