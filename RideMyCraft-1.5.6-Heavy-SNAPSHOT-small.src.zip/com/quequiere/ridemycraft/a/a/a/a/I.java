package com.quequiere.ridemycraft.a.a.a.a;

import com.quequiere.ridemycraft.Ridemycraft;
import com.quequiere.ridemycraft.a.a.a.a.a.b;
import com.quequiere.ridemycraft.d;
import org.bukkit.entity.Player;

public final class I extends k
{
  public final void a(com.quequiere.ridemycraft.car.a parama, Player paramPlayer)
  {
    if (Ridemycraft.version.equals(d.b))
    {
      new b().a(parama, paramPlayer);
      return;
    }
    if (Ridemycraft.version.equals(d.a))
      new com.quequiere.ridemycraft.a.a.a.a.a.a().a(parama, paramPlayer);
  }
}

/* Location:           C:\Users\keith\Desktop\RideMyCraft-1.5.6-Heavy-SNAPSHOT-small.jar
 * Qualified Name:     com.quequiere.ridemycraft.a.a.a.a.I
 * JD-Core Version:    0.6.2
 */