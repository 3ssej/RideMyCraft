package com.quequiere.ridemycraft.a.a.a.a;

import java.util.ArrayList;
import java.util.Iterator;
import me.xhawk87.PopupMenuAPI.MenuItem;
import me.xhawk87.PopupMenuAPI.PopupMenu;
import me.xhawk87.PopupMenuAPI.PopupMenuAPI;
import me.xhawk87.PopupMenuAPI.StringUtil;
import org.bukkit.entity.Player;

public final class J extends k
{
  public final void a(com.quequiere.ridemycraft.car.a parama, Player paramPlayer)
  {
    Object localObject = new ArrayList();
    for (float f = 0.0F; f <= 2.5F; f += 0.05F)
      ((ArrayList)localObject).add(new com.quequiere.ridemycraft.a(Math.round(f * 100.0F) / 100.0F));
    PopupMenu localPopupMenu = PopupMenuAPI.createMenu("Speed Modify menu", (int)Math.ceil(((ArrayList)localObject).size() / 9.0D));
    int i = 0;
    Iterator localIterator = ((ArrayList)localObject).iterator();
    while (localIterator.hasNext())
    {
      localObject = (com.quequiere.ridemycraft.a)localIterator.next();
      K localK;
      (localK = new K(this, ((com.quequiere.ridemycraft.a)localObject).c, com.quequiere.ridemycraft.a.a(), localPopupMenu, parama, (com.quequiere.ridemycraft.a)localObject)).setDescriptions(StringUtil.wrapWords("Set speed to " + ((com.quequiere.ridemycraft.a)localObject).c, 40));
      localPopupMenu.addMenuItem(localK, i);
      i++;
    }
    localPopupMenu.openMenu(paramPlayer);
  }
}

/* Location:           C:\Users\keith\Desktop\RideMyCraft-1.5.6-Heavy-SNAPSHOT-small.jar
 * Qualified Name:     com.quequiere.ridemycraft.a.a.a.a.J
 * JD-Core Version:    0.6.2
 */