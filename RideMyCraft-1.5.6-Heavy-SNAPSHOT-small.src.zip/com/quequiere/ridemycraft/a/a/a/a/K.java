package com.quequiere.ridemycraft.a.a.a.a;

import com.quequiere.ridemycraft.a.a.g;
import me.xhawk87.PopupMenuAPI.MenuItem;
import me.xhawk87.PopupMenuAPI.PopupMenu;
import org.bukkit.entity.Player;
import org.bukkit.material.MaterialData;

final class K extends MenuItem
{
  K(J paramJ, String paramString, MaterialData paramMaterialData, PopupMenu paramPopupMenu, com.quequiere.ridemycraft.car.a parama, com.quequiere.ridemycraft.a parama1)
  {
    super(paramString, paramMaterialData);
  }

  public final void onClick(Player paramPlayer)
  {
    this.a.closeMenu(paramPlayer);
    this.b.a(this.c.c);
    g.a(paramPlayer, this.b);
    try
    {
      this.b.a(true);
      return;
    }
    catch (com.quequiere.ridemycraft.b.a locala)
    {
      (paramPlayer = locala).printStackTrace();
    }
  }
}

/* Location:           C:\Users\keith\Desktop\RideMyCraft-1.5.6-Heavy-SNAPSHOT-small.jar
 * Qualified Name:     com.quequiere.ridemycraft.a.a.a.a.K
 * JD-Core Version:    0.6.2
 */