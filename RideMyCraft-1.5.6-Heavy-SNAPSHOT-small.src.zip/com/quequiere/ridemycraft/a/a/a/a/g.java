package com.quequiere.ridemycraft.a.a.a.a;

import org.bukkit.entity.Player;

public final class g extends h
{
  public final void a(com.quequiere.ridemycraft.c.b.b paramb, Player paramPlayer)
  {
    paramb.b();
  }

  public final void a(com.quequiere.ridemycraft.c.a.b paramb, Player paramPlayer)
  {
    paramb.b();
  }
}

/* Location:           C:\Users\keith\Desktop\RideMyCraft-1.5.6-Heavy-SNAPSHOT-small.jar
 * Qualified Name:     com.quequiere.ridemycraft.a.a.a.a.g
 * JD-Core Version:    0.6.2
 */