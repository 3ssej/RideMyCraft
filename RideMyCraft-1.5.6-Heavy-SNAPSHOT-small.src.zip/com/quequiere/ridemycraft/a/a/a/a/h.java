package com.quequiere.ridemycraft.a.a.a.a;

import org.bukkit.entity.Player;

public abstract class h
{
  public abstract void a(com.quequiere.ridemycraft.c.b.b paramb, Player paramPlayer);

  public abstract void a(com.quequiere.ridemycraft.c.a.b paramb, Player paramPlayer);
}

/* Location:           C:\Users\keith\Desktop\RideMyCraft-1.5.6-Heavy-SNAPSHOT-small.jar
 * Qualified Name:     com.quequiere.ridemycraft.a.a.a.a.h
 * JD-Core Version:    0.6.2
 */