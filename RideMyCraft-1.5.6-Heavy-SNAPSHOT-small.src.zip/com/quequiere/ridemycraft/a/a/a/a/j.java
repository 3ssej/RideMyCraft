package com.quequiere.ridemycraft.a.a.a.a;

import org.bukkit.entity.Player;

public final class j extends k
{
  public final void a(com.quequiere.ridemycraft.car.a parama, Player paramPlayer)
  {
    parama.h(!parama.s());
    try
    {
      parama.a(true);
      return;
    }
    catch (com.quequiere.ridemycraft.b.a locala)
    {
      (parama = locala).printStackTrace();
    }
  }
}

/* Location:           C:\Users\keith\Desktop\RideMyCraft-1.5.6-Heavy-SNAPSHOT-small.jar
 * Qualified Name:     com.quequiere.ridemycraft.a.a.a.a.j
 * JD-Core Version:    0.6.2
 */