package com.quequiere.ridemycraft.a.a.a.a;

import com.quequiere.ridemycraft.car.CarSeat;
import com.quequiere.ridemycraft.car.a;
import org.bukkit.entity.Player;

public abstract class k
{
  public abstract void a(a parama, Player paramPlayer);

  public void a(a parama, Player paramPlayer, CarSeat paramCarSeat)
  {
  }
}

/* Location:           C:\Users\keith\Desktop\RideMyCraft-1.5.6-Heavy-SNAPSHOT-small.jar
 * Qualified Name:     com.quequiere.ridemycraft.a.a.a.a.k
 * JD-Core Version:    0.6.2
 */