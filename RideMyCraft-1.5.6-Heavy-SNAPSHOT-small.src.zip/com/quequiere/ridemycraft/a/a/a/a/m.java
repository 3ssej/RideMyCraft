package com.quequiere.ridemycraft.a.a.a.a;

import org.bukkit.entity.Player;

public final class m extends k
{
  public final void a(com.quequiere.ridemycraft.car.a parama, Player paramPlayer)
  {
    parama.f(!parama.n());
    try
    {
      parama.a(true);
      return;
    }
    catch (com.quequiere.ridemycraft.b.a locala)
    {
      (parama = locala).printStackTrace();
    }
  }
}

/* Location:           C:\Users\keith\Desktop\RideMyCraft-1.5.6-Heavy-SNAPSHOT-small.jar
 * Qualified Name:     com.quequiere.ridemycraft.a.a.a.a.m
 * JD-Core Version:    0.6.2
 */