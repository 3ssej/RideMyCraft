package com.quequiere.ridemycraft.a.a;

import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

public final class c extends com.quequiere.ridemycraft.a.a
{
  public final void a(Player paramPlayer, String[] paramArrayOfString)
  {
    com.quequiere.ridemycraft.e.a.a(paramPlayer).a();
  }

  public final void a(ConsoleCommandSender paramConsoleCommandSender, String[] paramArrayOfString)
  {
    com.quequiere.ridemycraft.b.a.a.i.b();
  }
}

/* Location:           C:\Users\keith\Desktop\RideMyCraft-1.5.6-Heavy-SNAPSHOT-small.jar
 * Qualified Name:     com.quequiere.ridemycraft.a.a.c
 * JD-Core Version:    0.6.2
 */