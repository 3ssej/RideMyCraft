package com.quequiere.ridemycraft.a.a;

import me.xhawk87.PopupMenuAPI.MenuCloseBehaviour;
import org.bukkit.entity.Player;

final class i
  implements MenuCloseBehaviour
{
  public final void onClose(Player paramPlayer)
  {
  }
}

/* Location:           C:\Users\keith\Desktop\RideMyCraft-1.5.6-Heavy-SNAPSHOT-small.jar
 * Qualified Name:     com.quequiere.ridemycraft.a.a.i
 * JD-Core Version:    0.6.2
 */