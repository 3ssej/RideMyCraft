package com.quequiere.ridemycraft.a.a;

import com.quequiere.ridemycraft.f.a.b;
import org.bukkit.Location;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

public final class j extends com.quequiere.ridemycraft.a.a
{
  public static b a;

  public final void a(Player paramPlayer, String[] paramArrayOfString)
  {
    a = new b(paramPlayer.getLocation().clone().subtract(0.0D, 1.0D, 0.0D));
  }

  public final void a(ConsoleCommandSender paramConsoleCommandSender, String[] paramArrayOfString)
  {
    com.quequiere.ridemycraft.b.a.a.i.b();
  }
}

/* Location:           C:\Users\keith\Desktop\RideMyCraft-1.5.6-Heavy-SNAPSHOT-small.jar
 * Qualified Name:     com.quequiere.ridemycraft.a.a.j
 * JD-Core Version:    0.6.2
 */