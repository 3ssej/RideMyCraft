package com.quequiere.ridemycraft;

import org.mcstats.Metrics.Plotter;

final class b extends Metrics.Plotter
{
  b(String paramString)
  {
    super(paramString);
  }

  public final int getValue()
  {
    return 4;
  }
}

/* Location:           C:\Users\keith\Desktop\RideMyCraft-1.5.6-Heavy-SNAPSHOT-small.jar
 * Qualified Name:     com.quequiere.ridemycraft.b
 * JD-Core Version:    0.6.2
 */