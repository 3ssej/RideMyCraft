package com.quequiere.ridemycraft;

import org.mcstats.Metrics.Plotter;

final class c extends Metrics.Plotter
{
  c(String paramString)
  {
    super(paramString);
  }

  public final int getValue()
  {
    return 17;
  }
}

/* Location:           C:\Users\keith\Desktop\RideMyCraft-1.5.6-Heavy-SNAPSHOT-small.jar
 * Qualified Name:     com.quequiere.ridemycraft.c
 * JD-Core Version:    0.6.2
 */