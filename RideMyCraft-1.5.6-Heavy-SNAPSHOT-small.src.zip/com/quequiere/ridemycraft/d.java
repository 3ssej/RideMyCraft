package com.quequiere.ridemycraft;

public enum d
{
  static
  {
    { a }[1] = b;
  }
}

/* Location:           C:\Users\keith\Desktop\RideMyCraft-1.5.6-Heavy-SNAPSHOT-small.jar
 * Qualified Name:     com.quequiere.ridemycraft.d
 * JD-Core Version:    0.6.2
 */