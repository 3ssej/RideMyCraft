package me.xhawk87.PopupMenuAPI;

import org.bukkit.entity.Player;

public abstract interface MenuCloseBehaviour
{
  public abstract void onClose(Player paramPlayer);
}

/* Location:           C:\Users\keith\Desktop\RideMyCraft-1.5.6-Heavy-SNAPSHOT-small.jar
 * Qualified Name:     me.xhawk87.PopupMenuAPI.MenuCloseBehaviour
 * JD-Core Version:    0.6.2
 */