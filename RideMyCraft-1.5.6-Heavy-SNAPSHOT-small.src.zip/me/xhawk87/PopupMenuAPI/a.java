package me.xhawk87.PopupMenuAPI;

import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

final class a extends BukkitRunnable
{
  a(PopupMenu paramPopupMenu, Player paramPlayer)
  {
  }

  public final void run()
  {
    this.a.openMenu(this.b);
  }
}

/* Location:           C:\Users\keith\Desktop\RideMyCraft-1.5.6-Heavy-SNAPSHOT-small.jar
 * Qualified Name:     me.xhawk87.PopupMenuAPI.a
 * JD-Core Version:    0.6.2
 */